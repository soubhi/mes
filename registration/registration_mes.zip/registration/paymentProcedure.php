<!DOCTYPE html>
<?php
	// STARTING SESSION
	session_start();
	if ($_SESSION['logged_in'] != TRUE) {
		header("location: login.php");
	}

/********** CONNECTOIN TO MES-DATABASE ON BLUEHOST **************/
        // SET CONNECTION DETAILS
	
	define('DB_SERVER', 'mes10.uohyd.ac.in');
        define('DB_USERNAME', 'mes10pt8_mse10');
        define('DB_PASSWORD', 'vPV9k423%=mR');
        define('DB_DATABASE', 'mes10pt8_registration');
        // CONNECT TO THE DATABASE
        $conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE);

        if ($conn->connect_error) {
                echo "Connection Unsuccessful!"."<br />";
                echo $conn->connect_error;
                die();
        } else {
		echo "";                
		//echo "Connection Successful!";
                //echo "<br /> '".DB_USERNAME."' @ '".DB_SERVER."'";
                //echo "<br />"."Database : '".DB_DATABASE."'";
        }

?>
<html lang = "en-gb" dir = "ltr">

<head>
	<title>MES10 | Payment Procedure</title>
	<base href="/mes/" />
	<meta charset="utf-8">
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name = "viewport" content="width=device-width, initial-scale=1" />
	<link rel="stylesheet" href = "style.css" />
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel = "stylesheet" href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="javascript/jquery-1.10.2.js"></script>
</head>

<body>


<!------------ACTIVE TAB STYLE-------------------->
<style>
/*
	#registration-active {	
	    color: black !important;
	    background-color: white  !important;
	}
	#register-active {	
	    color: white !important;
	    background-color: teal  !important;
	}
	#registration-caret-active {
	    border-top-color: black !important;
	    border-bottom-color: black !important;
	}
*/
	table, th, td {
		border: 1px solid black;
		border-collapse: collapse;
		text-align:center;
	}	
</style>



<!------------------------------------heading----------------------------------------->
	<div id="heading-placeholder">

	<?php
		$include_path = "/home/mes10pt8/public_html/mes";
		$use_page="TRUE";
		include("$include_path/components/heading.php");
	?>

	</div>
<!---------------------------------end of heading------------------------------------->





<!---------------------------------Navigation bar------------------------------------->
	<div id="nav-placeholder">

	<?php
		include("$include_path/components/navigation-bar.php");
	?>

	</div>
<!-----------------------------end of Navigation bar----------------------------------->







<div class="container">
	<div class="row">

	<!--------------------------------page main content------------------------------->
		<div class="col-md-8">

		<br>
		<h4><strong><span style="font-size:17pt;text-align:justify;color:#008080;">MES10 Payment Procedure<br /></span></strong></h4>
		<br>
		<p>MES10 accepts payments through bank transfer.</p>

		<ul type = "1">
			<li>Registration fee will be payable in <strong>Indian Rupees (INR)</strong> only.</li>
			<li>We will follow the <strong>Indian Standard Time (IST).</strong> For those from countries to the west of India, it is important to remember that you day starts later than ours. For example, when it is 15th November for you, it may be already 16th November in India and you may have missed the chance to avail the early bird option.  Please ensure that you make payments sufficiently early so that you do not miss out on benefits because of time difference.</li>
		    <li>Each participant should send the copy of the <b>bank transfer receipt</b> by email to <a href = "mailto:mes10.secretariat@gmail.com">mes10.secretariat@gmail.com</a>. Only then the letter for getting your VISA will be issued.</li>
		</ul>
		<!-- 
		<p>Apart from the on-line registration form, each participant should also send the copy of the bank transfer receipt by email to <a href = "mailto:mes10.secretariat@gmail.com">mes10.secretariat@gmail.com</a>.Any form received without the payment receipt cannot be processed.</p>
		<p>Each participant should send the copy of the bank transfer receipt by email to <a href = "mailto:mes10.secretariat@gmail.com">mes10.secretariat@gmail.com</a>. Any form received without the payment receipt cannot be processed.</p>
		-->
		    
		<br><p><b>Bank Account details:</b></p>

		<ul style = "list-style-type:none">

			<li>Name of the bank: STATE BANK OF INDIA</li><br>

			<li>Account Holder: Mathematics Education and Society</li><br>

			<li>Bank Address: Raoof Mansion, Plot no 7&8 Dwaraka Nagar, Bandlaguda Jagir, Rajendra Nagar, Hyderabad 500008, Telangana, India</li><br>

			<li>Account Number: 37741797860</li><br>

			<li>(If you need a 17-digit Account number, use 0000003774179780)</li><br>

			<li>SWIFT Code/Routing Number: SBININBB315</li><br>

			<li>IFSC Code:  SBIN0017236</li><br>

			<li>Branch Code: 17236</li><br>

		</ul>
		</div>

	<!------------------------end of page main content------------------------------->


	<!------------------------------------sidebar------------------------------------>
		<div class="col-md-4">
			<div class="row">
				<div id="sidebar-dates-placeholder">
				
				<?php	
					include("$include_path/components/sidebar-dates.php");
				?>

				</div>
			</div>

			<div class="row">
		
			<?php	
				include("$include_path/components/poster.php");
			?>

			</div>
			<div class="row">
				<div id="sidebar-photos-placeholder">
				<?php	
					include("$include_path/components/sidebar-photos.php");
				?>
				</div>					
			</div>
		</div>
	<!---------------------------------end ofsidebar-------------------------------->
	
	</div>
</div>



<!-----------------footer---------------------------->
	<div id="footer-placeholder">
	<?php
		include("$include_path/components/footer.php");
	?>
	</div>
<!------------end of footer--------------------------->






</body>

</html>
