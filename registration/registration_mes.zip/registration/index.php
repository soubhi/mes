<?php
	header("location: ../");
?>
