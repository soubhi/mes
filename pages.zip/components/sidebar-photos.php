
<?php
	
	$pages_path = "/mes";


	if($use_page != "TRUE") {
		echo "Working";
		header("location: $pages_path/home.php");
	}


?>

<head>

<script type='text/javascript' src='https://amazingcarousel.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='https://amazingcarousel.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='https://amazingcarousel.com/wp-content/uploads/amazingcarousel/sharedengine/amazingcarousel.js?ver=1.2'></script>
</head>
<body>  

<!--<style>
h1 {
	text-align: center;	
	font-size : 20px;
}-->

</style>
<div id="wrapper" class="page-template page-template-demopage page-template-demopage-php page page-id-2676 page-child parent-pageid-2039 single-author singular two-column right-sidebar">
		<div class="sidebar-deadlines" style="margin-bottom: 0px !important"> <!--style-->


	<!--venue-block begins-->
	<div class ="venue-block">    <!--DONE-->
	


<!--<body class="page-template page-template-demopage page-template-demopage-php page page-id-2676 page-child parent-pageid-2039 single-author singular two-column right-sidebar">-->

<div id="page" class="hfeed">


	<div id="main">
		<div id="primary">
			<pre class="ve-block"><p><span style="left:27px;font-size: 13pt;font-family: Calibri,Candara,Segoe,Segoe UI,Optima,Arial;"><strong>  Hyderabad Photos</strong></span></p></pre>	
			<!--<div class="demo-title">
				<b><h1>Hyderabad photos</h1><b>
			</div>-->
                        
			<div class="demo-slider"><link rel="stylesheet" type="text/css" media="all" href="https://amazingcarousel.com/wp-content/uploads/amazingcarousel/15/carouselengine/initcarousel.css" />

<div id="amazingcarousel-container-15">
    <div id="amazingcarousel-15" style="display:block;position:relative;width:100%;max-width:200px;margin:0px auto 0px;">
        <div class="amazingcarousel-list-container">
            <ul class="amazingcarousel-list">

                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image">
	<a href="media/venue/cyber_towers.jpg" title="Cyber Towers"  class="html5lightbox" data-group="amazingcarousel-15"><img src="media/venue/compressed-toWidth200/cyber_towers.jpg"  alt="Cyber Towers" /></a>
</div>                    </div>
                </li>
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image">
	<a href="media/venue/hitech_road.jpg" title="Hitech city"  class="html5lightbox" data-group="amazingcarousel-15"><img src="media/venue/compressed-toWidth200/hitech_road.jpg"  alt="Hitech city" /></a>
</div>                    </div>
                </li>
                
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image">
	<a href="media/venue/birla-mandir-hyderabad.jpg" title="Birla Mandir"  class="html5lightbox" data-group="amazingcarousel-15"><img src="media/venue/compressed-toWidth200/birla-mandir-hyderabad.jpg"  alt="Birla Mandir" /></a>
</div>                    </div>
                </li>
		<li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image">
	<a href="media/venue/birla_mandir2.jpg" title="Birla Mandir"  class="html5lightbox" data-group="amazingcarousel-15"><img src="media/venue/compressed-toWidth200/birla_mandir2.jpg"  alt="Birla Mandir" /></a>
</div>                    </div>
                </li>
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image">
	<a href="media/venue/birla-planetarium-hyderabad-tourism-entryfee-timings-package-tour.jpg" title="Birla Planetorium"  class="html5lightbox" data-group="amazingcarousel-15"><img src="media/venue/compressed-toWidth200/birla-planetarium-hyderabad-tourism-entryfee-timings-package-tour.jpg"  alt="Birla Planetorium" /></a>
</div>                    </div>
                </li>          
                <li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image">
	<a href="media/venue/NBP_1308-001-e1434099191300.jpg" title="Hussain Sagar- with Buddha's statue at it's center"  class="html5lightbox" data-group="amazingcarousel-15"><img src="media/venue/compressed-toWidth200/nbp_1308_001_e143409_wuIhP.jpg"  alt="Hussain Sagar" /></a>
</div>                    </div>
                </li>
		<li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image">
	<a href="media/venue/Hyderabad-city-e1508867439150.jpg" title="The busy roads of Charminar"  class="html5lightbox" data-group="amazingcarousel-15"><img src="media/venue/compressed-toWidth200/hyderabad_city_e1508_WlLxU.jpg"  alt="Charminar" /></a>
</div>                    </div>
                </li>
		<li class="amazingcarousel-item">
                    <div class="amazingcarousel-item-container">
<div class="amazingcarousel-image">
	<a href="media/venue/hyderabad_shutterstock_147925229_web800.jpg" title="Lanco Hills"  class="html5lightbox" data-group="amazingcarousel-15"><img src="media/venue/compressed-toWidth200/hyderabad_shuttersto_kSr4Q.jpg"  alt="Lanco Hills" /></a>
</div>                    </div>
                </li>
            </ul>
            <div class="amazingcarousel-prev"></div>
            <div class="amazingcarousel-next"></div>
        </div>
        <!--<div class="amazingcarousel-nav"></div>
        <div class="amazingcarousel-engine"><a href="https://amazingcarousel.com">JavaScript Image Carousel</a></div>
        <div class="amazingcarousel-engine"><a href="https://amazingcarousel.com">WordPress Scroller</a></div>-->
    </div>
</div>
<script src="https://amazingcarousel.com/wp-content/uploads/amazingcarousel/15/carouselengine/initcarousel.js"></script>
</div>			
</div>
</div>
</div>

	</div><!--venue-block ends-->

	
</div>
<!-- footer-->
<footer  style="font-size:11px; text-align:right; padding: 0% 0% 30px 0%; font-weight: normal !important" ></footer>
</div>
				
</body>
